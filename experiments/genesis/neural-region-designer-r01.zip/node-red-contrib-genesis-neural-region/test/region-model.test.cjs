'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const m=require('../lib/region-model.cjs');

test('GENESIS default is correctly typed and explicitly design-only',()=>{
  const r=m.defaultRegion();assert.equal(r.schema,'mechanicus.neural-region/1');
  assert.equal(r.runtime.mode,'design-only');assert.equal(r.runtime.virtual_address_limit,500_000_000);
  assert.equal(m.validateRegion(r).ok,true);
});

test('exact integer neuron conservation, tie handling, and 500M virtual cap',()=>{
  assert.deepEqual(m.apportion(10,[1,1,1]),[4,3,3]);
  assert.deepEqual(m.apportion(1,[1,1,1]),[1,0,0]);
  const r=m.defaultRegion(),a=m.allocateLayers(r);
  assert.equal(a.total,1_000_000);assert.deepEqual(a.layers.map(x=>x.neurons),[30000,140000,240000,310000,180000,100000]);
  r.neurons.total=500_000_000;assert.equal(m.allocateLayers(r).total,500_000_000);
  r.neurons.total++;assert.equal(m.validateRegion(r).ok,false);
});

test('editing percentages redistributes other layers and conserves 100%',()=>{
  const r=m.defaultRegion();let next=m.redistributeShares(r.layers,3,37.53);
  assert.equal(next[3].share,37.53);
  assert.equal(next.reduce((a,b)=>a+Math.round(b.share*100),0),10000);
  const a=m.allocateLayers({...r,layers:next});assert.equal(a.layers.reduce((a,b)=>a+b.neurons,0),1_000_000);
  next=m.redistributeShares(next,3,100);
  assert.equal(next.reduce((a,b)=>a+Math.round(b.share*100),0),10000);
  assert.deepEqual(m.allocateLayers({...r,layers:next}).layers.map(x=>x.neurons),[0,0,0,1000000,0,0]);
});

test('invalid share or probability is rejected, not repaired silently',()=>{
  const r=m.defaultRegion();r.layers[1].share+=2;
  let v=m.validateRegion(r);assert.equal(v.ok,false);assert.ok(v.errors.some(x=>x.path==='layers.share'));
  r.layers[1].share-=2;r.projections[0].rule.probability=2;
  v=m.validateRegion(r);assert.equal(v.ok,false);assert.ok(v.errors.some(x=>x.path.endsWith('.probability')));
});

test('synapse/axon/pair quantities cannot be conflated',()=>{
  const r=m.defaultRegion();r.projections[0]={id:'P',source:'L1.E',target:'L2.E',rule:{mode:'exact'},quantity:{kind:'axons',value:300}};
  assert.equal(m.validateRegion(r).ok,true);
  assert.equal(m.estimateResources(r).unknown_projection_costs,1);
  r.projections[0].quantity={kind:'synaptic_contacts',value:300};
  assert.equal(m.estimateResources(r).estimated_known_synapse_bytes,300*24);
  delete r.projections[0].quantity.kind;
  assert.equal(m.validateRegion(r).ok,false);
});

test('absolute and density allocations have explicit numeric rules',()=>{
  const r=m.defaultRegion();r.neurons.allocation='absolute';r.layers.forEach((l,i)=>l.count=i+1);
  assert.deepEqual(m.allocateLayers(r).layers.map(x=>x.neurons),[1,2,3,4,5,6]);
  r.neurons.allocation='density';r.layers.forEach(l=>{l.volume_mm3=2;l.density_per_mm3=100;});
  assert.equal(m.allocateLayers(r).total,1200);
});

test('arbitrarily nested sublayers validated iteratively',()=>{
  const r=m.defaultRegion();let cur=r.layers[0];
  for(let i=0;i<400;i++){cur.sublayers=[{id:'N'+i,share:100,populations:[]}];cur=cur.sublayers[0];}
  assert.equal(m.validateRegion(r).ok,true);
  cur.sublayers=[{id:'Nbad',share:110,populations:[]}];
  assert.equal(m.validateRegion(r).ok,false);
});

test('biology is not invented for genome engineering',()=>{
  const r=m.defaultRegion();r.identity.classification='biological-reference';r.development.neurogenesis.enabled=true;
  const v=m.validateRegion(r);assert.equal(v.ok,true);assert.ok(v.warnings.some(w=>w.path.includes('neurogenesis')));
});

test('resource estimates distinguish full phenotype from active states',()=>{
  const r=m.defaultRegion();const e=m.estimateResources(r);
  assert.equal(e.virtual_addresses,1_000_000);assert.equal(e.active_states,896);
  assert.equal(e.estimated_full_neuron_bytes,64_000_000);
  assert.equal(e.estimated_active_neuron_bytes,896*64);
  assert.equal(e.unknown_projection_costs,1);
});

test('Node-RED editor and runtime scripts compile independently',()=>{
  const html=fs.readFileSync(path.join(__dirname,'..','neural-region.html'),'utf8');
  const source=html.match(/<script type="text\/javascript">([\s\S]*?)<\/script>/);
  assert.ok(source,'editor JavaScript source missing');new vm.Script(source[1]);
  const pkg=require('../package.json');
  assert.equal(pkg['node-red'].nodes['genesis-neural-region'],'neural-region.js');
});

test('Node-RED runtime only emits validated designer metadata',()=>{
  let ctor;
  const RED={nodes:{createNode:(n)=>{n.handlers={};n.on=function(t,fn){this.handlers[t]=fn;};},registerType:(name,fn)=>{assert.equal(name,'genesis-neural-region');ctor=fn;}}};
  require('../neural-region.js')(RED);
  const n=new ctor({name:'V1',region:JSON.stringify(m.defaultRegion())});
  let outgoing,completed=false;
  n.handlers.input({topic:'test'},msg=>{outgoing=msg;},()=>{completed=true;});
  assert.equal(completed,true);
  assert.equal(outgoing.genesis.execution,'not-started');
  assert.equal(outgoing.genesis.region.neurons.total,1_000_000);
});

test('typed Universal Graph IR roundtrip preserves layers, population chemistry and genome',()=>{
  const r=m.defaultRegion();r.layers[0].sublayers=[{id:'L1.a',share:65,populations:[{id:'E',kind:'excitatory',receptors:[{type:'GABA-A'}]}]},{id:'L1.b',share:35,populations:[]}];
  const ir=m.toUniversalGraphIR(r);
  assert.equal(ir.schema,'mechanicus.universal-graph/1');
  assert.equal(ir.nodes.filter(n=>n.kind==='neural.region').length,1);
  assert.ok(ir.edges.some(e=>e.kind==='neural.projection'));
  assert.deepEqual(m.fromUniversalGraphIR(ir),r);
});

test('IR safety: dangling containment and corrupted schemas fail closed',()=>{
  const ir=m.toUniversalGraphIR(m.defaultRegion());
  ir.edges.push({kind:'contains',source:'missing',target:ir.nodes[0].id,order:9});
  assert.throws(()=>m.fromUniversalGraphIR(ir),/dangling/);
  ir.edges.pop();ir.profile='unknown';
  assert.throws(()=>m.fromUniversalGraphIR(ir),/unknown graph IR/);
});

test('graph IR roundtrip keeps absent optional population arrays absent',()=>{
  const r=m.defaultRegion();delete r.layers[0].populations;
  assert.deepEqual(m.fromUniversalGraphIR(m.toUniversalGraphIR(r)),r);
});
