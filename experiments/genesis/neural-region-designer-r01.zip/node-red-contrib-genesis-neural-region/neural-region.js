'use strict';
const {defaultRegion,validateRegion,estimateResources,toUniversalGraphIR} = require('./lib/region-model.cjs');
/**
 * Schema-only description node. No neurons are materialized here.
 * External Neural Engine may subscribe to typed configuration messages.
 */
module.exports=function(RED){
  function GenesisNeuralRegion(config){
    RED.nodes.createNode(this,config);
    const node=this;
    node.name=config.name||'Neural Region';
    node.region=config.region||JSON.stringify(defaultRegion());
    node.on('input',(msg,send,done)=>{
      send=send||((...x)=>node.send(...x));
      let region;
      try{region=JSON.parse(node.region);}catch(err){if(done)return done(err);return node.error(err,msg);}
      const report=validateRegion(region);
      if(!report.ok){const err=new Error('GENESIS region invalid: '+report.errors.map(e=>e.path).join(', '));if(done)return done(err);return node.error(err,msg);}
      // Copy only typed, validated *configuration*. This node is not a brain simulator.
      msg.genesis={schema:region.schema,id:region.id,region,validation:report,resources:estimateResources(region),graph_ir:toUniversalGraphIR(region),execution:'not-started'};
      send(msg);
      if(done)done();
    });
  }
  RED.nodes.registerType('genesis-neural-region',GenesisNeuralRegion);
};
