# GENESIS Neural Region Designer R01

**Prototype of a Neural Region Designer palette node for Adamantium-node/Node-RED.**

A *Neural Region* node describes one region containing genetically controlled layers, nested modules, cell populations, projections, receptor metadata and developmental rules. It **does not** instantiate neurons or simulate biological dynamics. The reusable model library is deliberately Node.js-only and has no runtime, database, GPU, or Node-RED dependency.

## Install in isolated development Node-RED

On a machine where Node-RED is installed, install this folder as a local Node-RED contributed node package, for example from the Node-RED `userDir`:

```bash
npm install --no-save /absolute/path/to/node-red-contrib-genesis-neural-region
```

Restart that **development** instance of Node-RED and find **GENESIS → Neural Region** in the palette. Do not install on production or existing agent-workbench instances before backup and owner review. Import `examples/genesis-region-flow.json` on a new tab to inspect a simple configuration publisher.

The designer edits the `mechanicus.neural-region/1` data record using panels for region profile, layers, typed projections, genome source and Advanced JSON. When a flow message reaches the node, it emits `msg.genesis` containing the validated region record, a lossless typed `graph_ir` projection, resource estimate and `execution:'not-started'`.

## Contract

- **No fixed cortical architecture:** arbitrary `layers[]`, optional `sublayers[]`, arbitrary `populations[]`; non-biological ANN/rate/hybrid profiles allowed.
- **Precise neuron apportionment:** percentage allocation uses largest remainder, ensuring integer conservation. The editor redistributes shares after one value changes, with 0.01% steps.
- **Alternatives:** absolute neuron counts or neuron density × volume. Geometry and densities require explicit input, never guessed.
- **Explicit connectivity semantics:** projection `quantity.kind` is one of `synaptic_contacts`, `unique_neuron_pairs`, `axons`; modes include exact, probabilistic, spatial, topographic, genetic, learned, manual and imported. Only exact and probabilistic have initial mathematical validation; other algorithms are **described, not implemented**.
- **Chemistry:** receptor descriptions live on individual populations or can be finer-grained in `extensions`; AMPA/NMDA/GABA etc. are examples, not a hard-coded mandatory list.
- **Two genome tracks:** inherited `genome.source`, acquired `genome.acquired`, optional mutation bounds and epigenetic config. Historical edits need integration with a separate persistence service.
- **Budget:** up to 500,000,000 virtual neuron addresses (HQ500M); `active_budget` is distinct. Resource estimator is a lower bound with explicit assumptions, not a performance benchmark.
- **Graph IR:** `toUniversalGraphIR` and `fromUniversalGraphIR` preserve typed region/layer/population/projection structure. This is a GENESIS R01 profile, not an upstream Global Graph Manager API implementation.
- **Separations:** Universal Graph IR is canon; Node-RED is an optional editor. Simulation/learning, durable checkpoints, external model import, WireGuard scheduling, graph migrations and storage belong in independent MAS components. No autonomous edits of running regions occur here.
- **Extension contract:** `mechanicus.neural-region-field-plugin/1` and a descriptor list (`parameterDescriptors`) provide the path towards dynamically registered field forms and validators. R01 does not yet load third-party field plugins from MAS.

### Example

```json
{
  "schema": "mechanicus.neural-region/1",
  "id": "dante.visual.v1.left",
  "identity": {"name": "Experimental V1", "profile": "biological-spiking", "classification": "experimental"},
  "neurons": {"total": 1000000, "allocation": "percentages"},
  "layers": [{"id": "L1", "share": 100, "populations": []}],
  "projections": [],
  "runtime": {"mode": "design-only", "active_budget": 896, "virtual_address_limit": 500000000}
}
```

## Scientific discipline

NeuroML 2 and SONATA **interchange is planned but NOT implemented**. Biological atlas presets must carry provenance and never be misrepresented as measured where they are hypothetical. The example distribution for V1 is an engineering demonstration, not an atlas. Adult-cortex neurogenesis must not be labeled ordinary biology without evidence.

## Verification

`npm test` runs model/validation/editor compilation/passthrough tests offline, no services required. There is no live integration or multi-million-neuron runtime test in R01.

## Known R01 limitations

The Node-RED edit dialog supports layer percentage changes and projection CRUD, but nested sublayers and cell population details are edited primarily in Advanced JSON. No full-screen editor, native 3D visualization, inter-region matrix, molecular kinetics, distributed physical simulation or dynamic MAS plugin registry is installed. Those are follow-up plugin milestones, not fictional features.
